/* 
	AVR Software-Uart Demo-Application 
	Version 0.4, 10/2010
	
	by Martin Thomas, Kaiserslautern, Germany
	<eversmith@heizung-thomas.de>
	http://www.siwawi.arubi.uni-kl.de/avr_projects
*/

/* 
Test environment/settings: 
- avr-gcc 4.3.3/avr-libc 1.6.7 (WinAVR 3/2010)
- Atmel ATmega324P @ 8MHz internal RC, ATtiny85 @ 1MHz internal RC
- 2400bps
*/

/*
AVR Memory Usage (-Os, no-inline small-functions, relax)
----------------
Device: atmega324p

Program:     926 bytes (2.8% Full)
(.text + .data + .bootloader)

Data:         52 bytes (2.5% Full)
(.data + .bss + .noinit)


AVR Memory Usage (-Os)
----------------
Device: attiny85

Program:     828 bytes (10.1% Full)
(.text + .data + .bootloader)

Data:         52 bytes (10.2% Full)
(.data + .bss + .noinit)

*/

#define WITH_STDIO_DEMO   0 /* 1: enable, 0: disable */

#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include "softuart.h"

#define UART_BAUD_RATE      19200

#define UART_BAUD_SELECT (F_CPU/(UART_BAUD_RATE*16L)-1)

#if WITH_STDIO_DEMO
#include <stdio.h>

// interface between avr-libc stdio and software-UART
static int my_stdio_putchar( char c, FILE *stream )
{
	if ( c == '\n' ) {
		softuart_putchar( '\r' );
	}
	softuart_putchar( c );

	return 0;
}

FILE suart_stream = FDEV_SETUP_STREAM( my_stdio_putchar, NULL, _FDEV_SETUP_WRITE );

static void stdio_demo_func( void ) 
{
	stdout = &suart_stream;
	printf( "This output done with printf\n" );
	printf_P( PSTR("This output done with printf_P\n") );
}
#endif /* WITH_STDIO_DEMO */

SIGNAL(USART_RX_vect)  	//UART one byte Reception Complete Interrupt routine		   
{
	char received_char;
	received_char=UDR0;

	softuart_putchar(received_char);
}

SIGNAL(USART_TX_vect)  	//UART one byte Transmission Complete Interrupt routine		   
{

}

void uart_init(void)
{
    
    UCSR0B=((1<<RXCIE0)|(1<<TXCIE0)|(1<<RXEN0)|(1<<TXEN0));       
    UBRR0H=(UART_BAUD_SELECT>>8);
    UBRR0L=UART_BAUD_SELECT;    
      
}

int main(void)
{
	char c;

	uart_init();

	softuart_init();
	softuart_turn_rx_on(); /* redundant - on by default */
	
	sei();

#if WITH_STDIO_DEMO
	stdio_demo_func();
#endif
	
	for (;;)
	{
	
		if ( softuart_kbhit() )
		{
			c = softuart_getchar();
			UDR0 = c;
		}	
	}
	
	return 0; /* never reached */
}


